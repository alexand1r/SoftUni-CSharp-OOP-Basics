﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Car
{
    //public string model;
    //public float fuelAmmount;
    //public float distancePerKm;
    //public float distanceTraveled = 0;

    //public Car(string model, float fuelAmmount, float distancePerKm)
    //{
    //    this.model = model;
    //    this.fuelAmmount = fuelAmmount;
    //    this.distancePerKm = distancePerKm;
    //}
}
